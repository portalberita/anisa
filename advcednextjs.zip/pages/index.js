import Layout from '../layouts/layout';

function Main(){
  return (
    <Layout>
      <h2>Selamat Datang di Portal Berita</h2>
      <button><a href="/beranda">Lanjutkan</a></button>
    </Layout>
  )
}

export default Main;