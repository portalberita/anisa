function Header(){
	return (
	<header>
		<div>
			<h1><a href="/index">Portal Berita.com</a></h1>
			<p>Semua berita hangat ada disini</p>
		</div>
	</header>
	);
}

export default Header;