function Footer(){
	return (
	<div>
		<div>
            <hr/>
			<label>Instagram : @portal_berita.com | E-mail : portal_berita99@gmail.com | Facebook : facebook.com/portalberita99</label>
			<h3><a href="/index">Portal Berita.com</a></h3>
		</div>
	</div>
	);
}

export default Footer;